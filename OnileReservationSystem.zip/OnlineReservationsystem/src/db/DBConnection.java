package db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBConnection {
  private static final String URL=("jdbc:mysql://localhost:3306/train_db");
  private static final String USERNAME=("root");
  private static final String PASSWORD=("");
  
  public static Connection getConnection() {
	  Connection conn = null;
	  try {
		  conn = DriverManager.getConnection(URL,USERNAME,PASSWORD);
		//  System.out.println("Database connected succesfully");
		  
	  }
	  catch(SQLException e){
		  System.out.println("Dtabase connection failed");
		  e.printStackTrace();
	  }
	  return conn;
  }
}
