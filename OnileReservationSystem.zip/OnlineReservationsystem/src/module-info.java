/**
 * 
 */
/**
 * 
 */
module OnlineReservationsystem {
	requires java.sql;
}