package service;
import java.util.*;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import db.DBConnection;
//import java.time.*;

public class ReservationService {
	private Scanner sc;
	public ReservationService(Scanner sc)
	{
		this.sc = sc;
	}
	public String makeReservation(String username)
	{
			
		
		System.out.println("Enter train number");
		String trainno = sc.nextLine();
		//fetch train name 
		try(Connection conn = DBConnection.getConnection()){
		String trainName = null ; 
		String trainQuery= "Select train_name from trains where train_number = ?";
		PreparedStatement trainstmt = conn.prepareStatement(trainQuery);
		trainstmt.setString(1,trainno);

		ResultSet sr = trainstmt.executeQuery();
		if(sr.next()) {
			trainName=sr.getString("train_name");
			System.out.println("train found: " + trainName);
		}
		else {
			System.out.println("Train not found");
			return null;
		}
	
		System.out.println("Enter classtype");
		String classtype = sc.nextLine();
		
		System.out.println("Enter journey Date");
		String journeydate = sc.nextLine();
		
		System.out.println("Enter Source");
		String source = sc.nextLine();
		
		System.out.println("Enter Destination");
		String destination = sc.nextLine();
		
		//System.out.println("Enter PNR number");
		String pnr ="PR"+UUID.randomUUID().toString().substring(0,6);
	
				String sql = "Insert into reservations(username,train_number,train_name,class_type,journey_date,source,destination,pnr) values(?,?,?,?,?,?,?,?)";
				PreparedStatement stmt = conn.prepareStatement(sql);
				stmt.setString(1, username);
				stmt.setString(2, trainno);
				stmt.setString(3, trainName);
				stmt.setString(4, classtype);
				stmt.setString(5, journeydate);
				stmt.setString(6, source);
				stmt.setString(7, destination);
				stmt.setString(8, pnr);
				int RowsInserted = stmt.executeUpdate();
				if(RowsInserted>0)
				{
					System.out.println("record adeed");
					return pnr;
				}
				else {
					System.out.println("error in record");
					return null;
				}
				
		}
		catch(SQLException e) {
			System.out.println("Error in insert the record");
			e.printStackTrace();
			return null;
		}
		//System.out.println("booking ticket: " + username);
		
			
		}
	}

