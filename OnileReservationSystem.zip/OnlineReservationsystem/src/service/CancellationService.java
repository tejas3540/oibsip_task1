package service;

import java.sql.*;
import java.util.*;
import db.DBConnection;

public class CancellationService {
	private Scanner sc;
	public CancellationService(Scanner sc)
	{
		this.sc=sc;
	}
	public void cancelReservation()
	{
		System.out.println("Enter PNR Number");
		String pnr = sc.nextLine();
		try(Connection conn = DBConnection.getConnection())
		{
			String query = "Select * from reservations where pnr = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, pnr);
			
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				System.out.println("This is your ticket");
				System.out.println("Train no.: "+rs.getString("train_number"));
				System.out.println("Train Name: "+rs.getString("train_name"));
				System.out.println("Journey date: "+rs.getString("journey_date"));
				System.out.println("from: "+ rs.getString("source")+ " To: " + rs.getString("destination"));
				
			System.out.println("do you really want to cancel? (yes/no):");
			String confirm=sc.nextLine();
			 if(confirm.equalsIgnoreCase("yes")) {
				 String deleteQuery = "Delete from reservations where pnr = ?";
				 PreparedStatement deletestmt = conn.prepareStatement(deleteQuery);
				 deletestmt.setString(1,pnr);
				 int rows=deletestmt.executeUpdate();
				 
				 if(rows>0) {
					 System.out.println("Reservation cancelled");
				 }
				 else {
					 System.out.println("error in Cancellction"); 
				 }
			 }
			 else {
				 System.out.println("Cancellation abored!");
			 }
			}
			else
			{
				System.out.println("No reservation found for"+ pnr);
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
}
