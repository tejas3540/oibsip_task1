package service;
import java.util.*;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import db.DBConnection;

public class AuthService {
   private Scanner sc;
   public AuthService(Scanner sc) {
	   this.sc = sc;
   }
    
    public void userRegistraction(){
          System.out.println("Enter Username");
          String username = sc.nextLine();
          
          System.out.println("Enter password");
          String password = sc.nextLine();
         
          try( Connection conn = DBConnection.getConnection()) {
        	  
          String sql = "Insert into users(Username,Password)values(?,?)";
          PreparedStatement stmt =conn.prepareStatement(sql);
          stmt.setString(1, username);
          stmt.setNString(2, password);
          int rowInserted = stmt.executeUpdate();
          if(rowInserted > 0)
          {
        	  System.out.println("conn done");
          }
          else {
        	  System.out.println("failed");
          }
          stmt.close();
          conn.close();
          }
          catch(SQLException e){
          System.out.println("Error in inserting data");
          e.printStackTrace();
          }
          System.out.println("registered username: "+username+" password: "+password);
    }
    
    public String userLoginuser() {
    	
        System.out.println("Enter Username");
        String username = sc.nextLine();
        
        System.out.println("Enter password");
        String password = sc.nextLine();
try (Connection conn = DBConnection.getConnection())
    			{
       System.out.println("Attempt to login with username: "+username+" password: "+password);
        String sql = "select * from users where username = ? and password = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, username);
        stmt.setString(2, password);
        
        ResultSet rs = stmt.executeQuery();
        if(rs.next())
        {
        	return username;
        }
        else {
        	return null;
        }
 
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    		return null;
    	}
    }
}
