package app;
import java.util.*;
import service.AuthService;
import service.CancellationService;
import service.ReservationService;
public class Main {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	AuthService authservice = new AuthService(sc);
	ReservationService rc = new ReservationService(sc);
	CancellationService cancellationservice = new CancellationService(sc);
	//authservice.userRegistraction();
	
	String loggedInUsername=null;
	while(true) {
		System.out.println("**Train Reservation Service**");
		System.out.println("1. Register");
		System.out.println("2. login");
		System.out.println("3. Exit");
		int choice = 
				Integer.parseInt(sc.nextLine());
		switch(choice) {
		case 1:
			authservice.userRegistraction();
			break;
		
		case 2:
			loggedInUsername = authservice.userLoginuser();
			if(loggedInUsername != null)
			{
				boolean subMenu = true;
		        while (subMenu) {
		           
		            System.out.println("1. Make Reservation");
		            System.out.println("2. Cancel Reservation");
		            System.out.println("3. Logout");
		            System.out.print("Enter choice: ");
		            int subChoice = Integer.parseInt(sc.nextLine());

		            switch (subChoice) {
		                case 1:
		                    rc.makeReservation(loggedInUsername);
		                    break;
		                case 2:
		                    cancellationservice.cancelReservation();
		                    break;
		                case 3:
		                    System.out.println("Logging out...");
		                    loggedInUsername = null; // clear user
		                    subMenu = false; // exit loop
		                    break;
		                default:
		                    System.out.println("Invalid choice.");
		            }
		        }
		    }
			break;
			
		case 3:
			System.out.println("Exit thankyou for visit");
			sc.close();
			System.exit(0);
			break;
			default:
				
				System.out.println("Invalid choices, try again");
	}
		
		
}
}
}